package ec.edu.espe;

import ec.edu.espe.datos.repository.EstudianteRepository;
import ec.edu.espe.logica_negocio.EstudianteService;
import ec.edu.espe.presentacion.EstudianteUI;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Crear repo y servicio
        EstudianteRepository repo = new EstudianteRepository();
        EstudianteService service = new EstudianteService(repo);

        // Datos de ejemplo
        try {
            service.agregarEstudiante(new ec.edu.espe.datos.model.Estudiante("ADS1", "Kevin Amaguaña", 23));
            service.agregarEstudiante(new ec.edu.espe.datos.model.Estudiante("ADS2", "Jairo Bonilla", 22));
            service.agregarEstudiante(new ec.edu.espe.datos.model.Estudiante("ADS3", "Daniel Guaman", 22));
            service.agregarEstudiante(new ec.edu.espe.datos.model.Estudiante("ADS4", "Reishel Tipan", 22));
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            EstudianteUI ui = new EstudianteUI(service);
            ui.setVisible(true);
        });
    }
}
