package ec.edu.espe.datos.repository;

import ec.edu.espe.datos.model.Estudiante;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class EstudianteRepository {
    private final List<Estudiante> estudiantes = new ArrayList<>();

    public void agregar(Estudiante e) {
        estudiantes.add(e);
    }

    public boolean editar(String id, Estudiante nuevo) {
        Optional<Estudiante> opt = estudiantes.stream()
                .filter(s -> s.getId().equals(id))
                .findFirst();
        if (opt.isPresent()) {
            Estudiante existente = opt.get();
            existente.setNombres(nuevo.getNombres());
            existente.setEdad(nuevo.getEdad());
            return true;
        }
        return false;
    }

    public boolean eliminar(String id) {
        return estudiantes.removeIf(s -> s.getId().equals(id));
    }

    public List<Estudiante> listar() {
        return new ArrayList<>(estudiantes); // devolver copia para seguridad
    }

    public Estudiante buscarPorId(String id) {
        return estudiantes.stream()
                .filter(s -> s.getId().equals(id))
                .findFirst()
                .orElse(null);
    }
}
